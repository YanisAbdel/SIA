ultralytics
opencv-python
pandas
psutil
jetson-stats